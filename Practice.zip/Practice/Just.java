import java.util.*;
class Just
{
public static void main(String[] args)
{
Scanner my=new Scanner(System.in);
String A=my.nextLine();
System.out.println(A);
}
}