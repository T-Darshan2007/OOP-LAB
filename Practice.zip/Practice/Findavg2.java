import java.util.*;

class Findavg2{
	public int findavg(int a, int b, int c){
		return (a+b+c)/3;
	}
	
	public static void main(String args[]){
		Scanner you=new Scanner(System.in);
		int n1=you.nextInt();
		int n2=you.nextInt();
		int n3=you.nextInt();
		Findavg2 my=new Findavg2();
		System.out.println("Average:" + my.findavg(n1, n2, n3));
	}
}