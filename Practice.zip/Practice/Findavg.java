class Findavg{
	public int findavg(int a, int b, int c){
		return (a+b+c)/3;
	}
	
	public static void main(String args[]){
		Findavg you=new Findavg();
		int hi=you.findavg(10, 20, 30);
		System.out.println("Avergae of 10, 20, and 30 is:" + hi);
	}
}