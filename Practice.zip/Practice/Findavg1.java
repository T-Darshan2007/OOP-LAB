class Findavg1{
	public int findavg(int a, int b, int c){
		return (a+b+c)/3;
	}
	
	public static void main(String args[]){
		Findavg1 you=new Findavg1();
		System.out.println("Avergae of 10, 20, and 30 is:" + you.findavg(10, 20, 30));
	}
}